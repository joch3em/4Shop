## Inloggen

 - Na het draaien van de seeds kun je inloggen via:
 - http://<link-naar-app>/admin
 - winkelbeheer@example.com
 - Welkom01
